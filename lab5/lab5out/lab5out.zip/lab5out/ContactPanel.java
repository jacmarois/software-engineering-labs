package lab5out;

import java.awt.*;
import javax.swing.*;

public class ContactPanel extends JPanel
{
	public ContactPanel()
	{
		JLabel contactLbl = new JLabel("Contacts");
		
		JTextArea contactsList = new JTextArea();
		
		JButton delContact = new JButton("Delete Contact");
		JButton addContact = new JButton("Add Contact");
		JButton logOut = new JButton("Log Out");
		
		JPanel grid = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		grid.add(contactLbl, c);
		
		c.gridy = 1;		
		grid.add(contactsList,c);
		
		c.gridy = 2;
		c.gridwidth = 1;
		grid.add(delContact, c);
		
		c.gridx = 1;
		grid.add(addContact, c);
		
		c.gridx = 0;
		c.gridy = 3;
		c.gridwidth = 2;
		grid.add(logOut, c);
		
	}
}
