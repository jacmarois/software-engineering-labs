package lab5out;

import java.util.ArrayList;

public class CreateAccountData
{
	private ArrayList<User> users = new ArrayList<User>();
	
	public CreateAccountData()
	{
		
	}
}
