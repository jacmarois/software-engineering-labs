package lab5out;

import ocsf.client.AbstractClient;

public class ChatClient extends AbstractClient
{
	
	private boolean loginStatus = false;
  
  public ChatClient()
  {
    super("localhost",8300);
  }

  @Override
  public void handleMessageFromServer(Object arg0)
  {
	  if(! (( String )arg0).contains("ServerError01")) {
		  //Successful login
		  System.out.println("Server Message sent to Client " + (String)arg0);
		  loginStatus = true;
	  }
	  else
	  {
		  loginStatus = false;
	  }
	  
  }
  
  public void connectionException (Throwable exception) 
  {
    //Add your code here
  }
  public void connectionEstablished()
  {
    //Add your code here
  }
  
  public boolean getLoginStatus() {
	  return loginStatus;
  }

}
