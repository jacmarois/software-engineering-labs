package lab8out;

import ocsf.client.AbstractClient;

public class ChatClient extends AbstractClient
{
	
	private boolean loginStatus = false;
	private boolean validAccount = false;
  
  public ChatClient()
  {
    super("localhost",8300);
  }

  @Override
  public void handleMessageFromServer(Object arg0)
  {
	  if((( String )arg0).contains("ServerError01"))
	  {
		  //Couldn't create account
		  loginStatus = false;
		  validAccount = false;
	  }
	  else if((( String )arg0).contains("ServerError02"))
	  {
		  //Couldn't login
		  loginStatus = false;
		  validAccount = false;
	  }
	  else if(((String)arg0).contains("username:Client-"))
	  {
		  //Server says we connected
		  //Do nothing
	  }
	  else if(((String)arg0).equals("ACS"))
	  {
		  validAccount = true;
	  }
	  else if(((String)arg0).equals("LIS"))
	  {
		  loginStatus = true;
	  }
	  else
	  {
		  System.out.println("Server Message sent to Client " + (String)arg0);
	  }
	  
  }
  
  public void connectionException (Throwable exception) 
  {
    //Add your code here
  }
  public void connectionEstablished()
  {
    //Add your code here
  }
  
  public boolean getLoginStatus() {
	  return loginStatus;
  }
  public boolean getValidAccount() {
	  return validAccount;
  }

}
