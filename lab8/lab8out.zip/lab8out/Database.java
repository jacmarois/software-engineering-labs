package lab8out;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Database
{
  private Connection conn;
  
  public void setConnection(String fn) 
  {
	  ArrayList<String> args = new ArrayList<String>();
	  
	  try (BufferedReader br = new BufferedReader(new FileReader("./lab7out/db.properties")))
	  {
		  String line;
		  while( (line = br.readLine()) != null )
		  {
			  if(line.contains("="))
			  {
				  args.add(line.split("=")[1]);
			  }
		  }
	  } catch (FileNotFoundException e)
	  {
		  e.printStackTrace();
	  } catch (IOException e1)
	  {
		  e1.printStackTrace();
	  }
	  
	  try
	  {
		conn = DriverManager.getConnection(args.get(2),args.get(0),args.get(1));
	  } catch (SQLException e)
	  {
		e.printStackTrace();
	  }
  }

  public Connection getConnection()
  {
    return conn;
  }

  
  public ArrayList<String> query(String query)
  {
	  ArrayList<String> ret = new ArrayList<String>();
	  
	  try
	{
		Statement q = conn.createStatement();
		ResultSet rs = q.executeQuery(query);
		ResultSetMetaData rsmd = rs.getMetaData();
		
		if(rsmd.getColumnCount() == 0)
		{
			return null;
		}
		
		while(rs.next())
		{
			String[] row = new String[rsmd.getColumnCount()];
			
			for(int i = 1; i <= rsmd.getColumnCount(); i++)
			{
				row[i-1] = rs.getString(i);
			}
			
			ret.add(String.join(",", row));
		}
	} catch (SQLException e)
	{
		e.printStackTrace();
		return null;
	}
	  
	  return ret;
  }
  
  public void executeDML(String dml) throws SQLException
  {
	  Statement q = conn.createStatement();
	  q.executeUpdate(dml);
  }
  
}
