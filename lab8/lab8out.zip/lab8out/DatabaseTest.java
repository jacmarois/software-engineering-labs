package lab8out;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import lab8in.DatabaseFile;

public class DatabaseTest
{

	String[] users = {"jsmith@uca.edu","msmith@uca.edu","tjones@yahoo.com","jjones@yahoo.com"};
	String[] passwords = {"hello123","pass123","123456","hello1234"};

	private Database db;
	
	@Before
	public void setUp() throws Exception 
	{
	  db = new Database(); 
	}
	
	@Test
	public void testSetConnection()
	{
		db.setConnection("lab8out/db.properties");
		if(db.getConnection() == null)
			fail("No Connection.");
	}

	@Test
	public void testQuery()
	{
		db.setConnection("lab8out/db.properties");
		if(db.getConnection() != null)
		{
			ArrayList<String> password = db.query("select password,aes_decrypt(password,'key') from users where username='jjones@yahoo.com';");
			if(!password.get(0).split(",")[2].equals("hello1234"))
				fail("Incorrect password.");
		}
	}

	@Test
	public void testExecuteDML()
	{
		db.setConnection("lab8out/db.properties");
		if(db.getConnection() != null)
		{
			try
			{
				db.executeDML("insert into users values('test@test.com', aes_encrypt('testpassword', 'key'));");
			}
			catch(SQLException e)
			{
				fail("DML could not be executed.");
			}
		}
	}

}
