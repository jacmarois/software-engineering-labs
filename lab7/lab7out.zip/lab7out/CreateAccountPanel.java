package lab7out;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class CreateAccountPanel extends JPanel
{
	
	private CreateAccountControl cac;
	
	private JTextField usernameField;
	private JPasswordField passwordField;
	private JPasswordField pass2;
	private JLabel errorLabel;
	
	// Getter for the text in the username field.
	public String getUsername()
	{
		return usernameField.getText();
	}
	
	// Getter for the text in the password field.
	public String getPassword()
	{
		return new String(passwordField.getPassword());
	}
	
	public String getPass2()
	{
		return new String(pass2.getPassword());
	}
	
	// Setter for the error text.
	public void setError(String error)
	{
		errorLabel.setText(error);
	}
	
	public CreateAccountPanel(CreateAccountControl cac)
	{
		JPanel mainPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		
		c.gridx = 0;
		c.gridy = 0;
		c.gridwidth = 2;
		c.weightx = .5;
		c.insets = new Insets(5,10,5,10);
		errorLabel = new JLabel("", JLabel.CENTER);
	    errorLabel.setForeground(Color.RED);
	    mainPanel.add(errorLabel,c);
	    
	    c.gridy++;
	    JLabel instructionLabel = new JLabel("Enter your username and password to log in.", JLabel.CENTER);
		mainPanel.add(instructionLabel,c);
		
		c.gridy++;
	    JLabel passLenLabel = new JLabel("Password must be at least 6 characters long.", JLabel.CENTER);
		mainPanel.add(passLenLabel,c);
		
		c.gridy++;
		c.gridwidth = 1;
		JLabel usernameLabel = new JLabel("Username:", JLabel.RIGHT);
		mainPanel.add(usernameLabel,c);
		
		c.gridx++;
	    usernameField = new JTextField(10);
	    mainPanel.add(usernameField,c);
	    
	    c.gridy++;
	    c.gridx = 0;
	    JLabel passwordLabel = new JLabel("Password:", JLabel.RIGHT);
	    mainPanel.add(passwordLabel,c);
	    
	    c.gridx++;
	    passwordField = new JPasswordField(10);
	    mainPanel.add(passwordField,c);
	    
	    c.gridy++;
	    c.gridx = 0;
	    JLabel pass2Label = new JLabel("Verify Password:", JLabel.RIGHT);
	    mainPanel.add(pass2Label,c);
	    
	    c.gridx++;
	    pass2 = new JPasswordField(10);
	    mainPanel.add(pass2,c);
	    
	    c.gridy++;
	    c.gridx = 0;
	    c.gridwidth = 1;
	    c.fill = GridBagConstraints.HORIZONTAL;
	    JButton submitButton = new JButton("Submit");
	    submitButton.addActionListener(cac);
	    mainPanel.add(submitButton,c);
	    
	    c.gridx++;
	    JButton cancelButton = new JButton("Cancel");
	    cancelButton.addActionListener(cac);
	    mainPanel.add(cancelButton,c);
	    
	    this.add(mainPanel);
	}
	
}
