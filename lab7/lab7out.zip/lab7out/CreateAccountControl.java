package lab7out;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JPanel;

public class CreateAccountControl implements ActionListener
{
	
	// Private data fields for the container and chat client.
	private JPanel container;
	private ChatClient cc;
	  
	  
	// Constructor for the login controller.
	public CreateAccountControl(JPanel container, ChatClient cc)
	{
		this.container = container;
	    this.cc = cc;
	}
	  
	// Handle button clicks.
	public void actionPerformed(ActionEvent ae)
	{
	    // Get the name of the button clicked.
	    String command = ae.getActionCommand();

	    // The Cancel button takes the user back to the initial panel.
	    if (command == "Cancel")
	    {
	    	CardLayout cardLayout = (CardLayout)container.getLayout();
	    	cardLayout.show(container, "1");
	    }

	    // The Submit button submits the login information to the server.
	    else if (command == "Submit")
	    {
	    	// Get the username and password the user entered.
	    	CreateAccountPanel caPanel = (CreateAccountPanel)container.getComponent(2);
	    	CreateAccountData data = new CreateAccountData(caPanel.getUsername(), caPanel.getPassword());
	      
	    	// Check the validity of the information locally first.
	    	if (data.getUsername().equals("") || data.getPassword().equals(""))
	    	{
	    		displayError("You must enter a username and password.");
	    		return;
	    	}
	    	else if(data.getPassword().length() < 6)
	    	{
	    		displayError("Your password must be at least 6 characters.");
	    		return;
	    	}
	    	else if(!data.getPassword().equals(caPanel.getPass2()))
	    	{
	    		displayError("The passwords do not match.");
	    		return;
	    	}

	    	// Submit the account information to the server.
	    	try
	    	{
	    		cc.openConnection();
	    		cc.sendToServer(data);
	    		Thread.sleep(300);
	    		if(cc.getValidAccount())
	    		{
	    			accountSuccess();
	    		}
	    		else
	    		{
	    			displayError("The username is taken.");
	    		}
	    	} catch (IOException e)
	    	{
	    		// TODO Auto-generated catch block
	    		e.printStackTrace();
	    	} catch (InterruptedException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	}

	public void accountSuccess()
	{
		CardLayout cardLayout = (CardLayout)container.getLayout();
	    cardLayout.show(container, "2");
	}

	// Method that displays a message in the error - could be invoked by ChatClient or by this class (see above)
	public void displayError(String error)
	{
		CreateAccountPanel caPanel = (CreateAccountPanel)container.getComponent(2);
		caPanel.setError(error);
	}

}
