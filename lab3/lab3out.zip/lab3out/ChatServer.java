package lab3out;

import java.awt.Color;
import java.io.IOException;

import javax.swing.JLabel;
import javax.swing.JTextArea;

import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

public class ChatServer extends AbstractServer
{
	
	private JLabel status;
	private JTextArea log;
	
	public ChatServer()
	{
		super(12345);
		super.setTimeout(500);
	}

	@Override
	protected void handleMessageFromClient(Object arg0, ConnectionToClient arg1)
	{
		
		//System.out.println("Client message sent to server.");
		log.append("Client-" + arg1.getId() + ": " + (String)arg0 + "\n");
		try
		{
			arg1.sendToClient((String)arg0);
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void listeningException(Throwable exception)
	{
		
		System.out.println("Listening Exception Occured!");
		System.out.println(exception.getMessage());
		exception.printStackTrace();
		log.append(exception.getMessage() + "\n");
		log.append("Press Listen to Restart Server\n");
		status.setForeground(new Color(255,0,0));
		status.setText("Exception Occurred when Listening");
		
	}
	
	public void serverStarted()
	{
		//System.out.println("Server Started");
		status.setForeground(new Color(0,255,0));
		status.setText("Listening");
		log.append("Server Started\n");
	}
	
	public void serverStopped()
	{
		status.setForeground(new Color(255,0,0));
		status.setText("Stopped");
		log.append("Server Stopped Accepting New Clients - Press Listen to Start Accepting New Clients\n");
	}
	
	public void serverClosed()
	{
		status.setForeground(new Color(255,0,0));
		status.setText("Closed");
		log.append("Server and all current clients are closed - Press Listen to Restart\n");
		
	}
	
	public void clientConnected(ConnectionToClient client)
	{
		log.append("Client-" + client.getId() + " Connected\n");
		try
		{
			client.sendToClient("username:Client-" + client.getId());
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void setStatus(JLabel s)
	{
		status = s;
	}
	
	public void setLog(JTextArea l)
	{
		log = l;
	}

}
