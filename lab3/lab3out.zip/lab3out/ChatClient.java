package lab3out;

import java.awt.Color;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ocsf.client.AbstractClient;

public class ChatClient extends AbstractClient
{
	
	private JLabel status;
	private JTextArea serverMsg;
	private JTextField clientID;
	private String cID;

	public ChatClient()
	{
		super("loaclhost", 8300);
	}

	@Override
	protected void handleMessageFromServer(Object msg)
	{
		//System.out.println("Server Message sent to Client: " + msg);
		Pattern command = Pattern.compile("[a-zA-Z0-9-]*:[a-zA-Z0-9-]*");
		Matcher m = command.matcher((String)msg);
		if(m.matches())
		{
			String cmd = m.group(0).split(":")[0];
			String arg = m.group(0).split(":")[1];
			System.out.println("Server issued command: " + m.group(0));
			switch(cmd)
			{
				case "username":
					clientID.setText(arg);
					break;
				default:
					serverMsg.append("Command not recognized\n");
					break;
			}
		}
		serverMsg.append("Server: " + (String)msg + "\n");
	}
	
	public void connectionException (Throwable exception)
	{
		System.out.println("Connection Exception occurred.");
		System.out.println(exception.getMessage());
		exception.printStackTrace();
	}
	
	public void connectionEstablished()
	{
		//System.out.println("Client Connected");
		status.setForeground(new Color(0,255,0));
		status.setText("Connected");
	}
	
	public void connectionClosed()
	{
		status.setForeground(new Color(255,0,0));
		status.setText("Not Connected");
	}

	public void setStatus(JLabel status)
	{
		this.status = status;
	}
	
	public void setServerMsg(JTextArea serverMsg)
	{
		this.serverMsg = serverMsg;
	}
	
	public void setClientID(JTextField clientID)
	{
		this.clientID = clientID;
	}
}
