package lab3out;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.*;
import java.io.IOException;

public class ClientGUI extends JFrame
{
  private ChatClient client;
  
  private JLabel status;
  private JButton connect;
  private JButton submit;
  private JButton stop;
  private String[] labels = {"Client ID","Server URL","Server Port"};
  private JTextField[] textFields = new JTextField[labels.length];
  private JTextArea clientArea;
  private JTextArea serverArea;
  
  public ClientGUI(String title)
  {
    this.setTitle(title);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //ADD YOUR CODE HERE TO CREATE THE STATUS JLABEL AND THE JBUTTONS
    this.setPreferredSize(new Dimension(800,600));
    
    status = new JLabel("Not Connected");
    status.setForeground(new Color(255,0,0));
    
    JPanel north = new JPanel(new FlowLayout());
    north.add(new JLabel("Status:"));
    north.add(status);
    
    JPanel center = new JPanel(new GridBagLayout());
    GridBagConstraints c = new GridBagConstraints();
    
    c.fill = GridBagConstraints.NONE;
    c.gridx = 0;
    c.gridy = 0;
    c.anchor = GridBagConstraints.LINE_END;
    c.insets = new Insets(5,5,5,5);
    c.weightx = 0.5;
    c.weighty = 0.05;
    JLabel temp = new JLabel(labels[0]);
    temp.setHorizontalAlignment(JLabel.RIGHT);
    center.add(temp,c);
    
    c.gridx = 1;
    c.gridy = 0;
    c.anchor = GridBagConstraints.LINE_START;
    textFields[0] = new JTextField();
    textFields[0].setEditable(false);
    textFields[0].setColumns(15);
    center.add(textFields[0],c);
    
    c.gridx = 0;
    c.gridy = 1;
    c.anchor = GridBagConstraints.LINE_END;
    temp = new JLabel(labels[1]);
    temp.setHorizontalAlignment(JLabel.RIGHT);
    center.add(temp,c);
    
    c.gridx = 1;
    c.gridy = 1;
    c.anchor = GridBagConstraints.LINE_START;
    textFields[1] = new JTextField();
    textFields[1].setColumns(15);
    center.add(textFields[1],c);
    
    c.gridx = 0;
    c.gridy = 2;
    c.anchor = GridBagConstraints.LINE_END;
    temp = new JLabel(labels[2]);
    temp.setHorizontalAlignment(JLabel.RIGHT);
    center.add(temp,c);
    
    c.gridx = 1;
    c.gridy = 2;
    c.anchor = GridBagConstraints.LINE_START;
    textFields[2] = new JTextField();
    textFields[2].setColumns(10);
    center.add(textFields[2],c);
    
    c.gridx = 0;
    c.gridy = 3;
    c.anchor = GridBagConstraints.CENTER;
    c.insets = new Insets(50,100,5,100);
    c.gridwidth = 2;
    center.add(new JLabel("Enter Client Data Below"),c);
    
    c.gridx = 0;
    c.gridy = 4;
    c.anchor = GridBagConstraints.CENTER;
    c.insets = new Insets(5,100,5,100);
    c.fill = GridBagConstraints.BOTH;
    clientArea = new JTextArea(5,20);
    JScrollPane caPane = new JScrollPane(clientArea);
    center.add(caPane,c);
    
    c.gridx = 0;
    c.gridy = 5;
    c.anchor = GridBagConstraints.CENTER;
    c.fill = GridBagConstraints.NONE;
    center.add(new JLabel("Received Server Data"),c);
    
    c.gridx = 0;
    c.gridy = 6;
    c.anchor = GridBagConstraints.CENTER;
    c.fill = GridBagConstraints.BOTH;
    serverArea = new JTextArea(5,20);
    serverArea.setEditable(false);
    JScrollPane saPane = new JScrollPane(serverArea);
    center.add(saPane,c);
    
    connect = new JButton("Connect");
    connect.addActionListener(new EventHandler("connect"));
    submit = new JButton("Submit");
    submit.addActionListener(new EventHandler("submit"));
    stop = new JButton("Stop");
    stop.addActionListener(new EventHandler("stop"));
    
    JPanel south = new JPanel(new FlowLayout());
    south.add(connect);
    south.add(submit);
    south.add(stop);
    
    this.setLayout(new BorderLayout());
    this.add(north, BorderLayout.NORTH);
    this.add(center, BorderLayout.CENTER);
    this.add(south, BorderLayout.SOUTH);
    
    this.pack();
    this.setVisible(true);
    
    client = new ChatClient();
    client.setServerMsg(serverArea);
    client.setClientID(textFields[0]);
    client.setStatus(status);
    
  }
  
  class EventHandler implements ActionListener
  {
	
	private String input;
	  
	public EventHandler(String input)
	{
		this.input = input;
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(input == "connect") {connect();}
		else if(input == "submit") {submit();}
		else if(input == "stop") {stop();}
	}
	
	public void connect()
	{
		//System.out.println("Connect Button Pressed");
		if(!client.isConnected())
		{
			try
			{
				if(!textFields[1].getText().isEmpty() && (Integer.parseInt(textFields[2].getText()) >= 1024 && Integer.parseInt(textFields[2].getText()) <= 64000))
				{
					client.setHost(textFields[1].getText());
					client.setPort(Integer.parseInt(textFields[2].getText()));
					client.openConnection();
				}
				else
				{
					serverArea.append("You must enter a hostname/port number first\n");
				}
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void submit()
	{
		//System.out.println("Submit Button Pressed");
		//System.out.println("Client data: " + clientArea.getText());
		if(client.isConnected())
		{
			if(!clientArea.getText().isEmpty())
			{
				try
				{
				client.sendToServer(clientArea.getText());
				} catch (IOException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				clientArea.setText("");
			}
		}
		else
		{
			clientArea.append("You must be connected to a server\n");
		}
	}
	
	public void stop()
	{
		//System.out.println("Stop Button Pressed");
		if(client.isConnected())
		{
			try
			{
				client.closeConnection();
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	  
  }
  
  public static void main(String[] args)
  {
    new ClientGUI(args[0]); //args[0] represents the title of the GUI
  }
}
