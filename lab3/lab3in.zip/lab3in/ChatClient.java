package lab3in;

import ocsf.client.AbstractClient;

public class ChatClient extends AbstractClient
{

	public ChatClient()
	{
		super("loaclhost", 8300);
	}

	@Override
	protected void handleMessageFromServer(Object msg)
	{
		System.out.println("Server Message sent to Client: " + msg);
	}
	
	public void connectionException (Throwable exception)
	{
		System.out.println("Connection Exception occurred.");
		System.out.println(exception.getMessage());
		exception.printStackTrace();
	}
	
	public void connectionEstablished()
	{
		System.out.println("Client Connected");
	}

}
