package lab1in;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.*;

public class ClientGUI extends JFrame
{
  private JLabel status;
  private JLabel statusType;
  private JButton connect;
  private JButton submit;
  private JButton stop;
  
  public ClientGUI(String title)
  {
    int i = 0;
    
    this.setTitle(title);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    //ADD YOUR CODE HERE TO CREATE THE STATUS JLABEL AND THE JBUTTONS
    this.setPreferredSize(new Dimension(600,400));
    
    statusType = new JLabel("Not Connected");
    statusType.setForeground(new Color(255,0,0));
    status = new JLabel("Status:");
    
    JPanel north = new JPanel(new FlowLayout());
    north.add(status);
    north.add(statusType);
    
    connect = new JButton("Connect");
    connect.addActionListener(new EventHandler(connect, submit, stop));
    submit = new JButton("Submit");
    submit.addActionListener(new EventHandler(connect, submit, stop));
    stop = new JButton("Stop");
    stop.addActionListener(new EventHandler(connect, submit, stop));
    
    JPanel south = new JPanel(new FlowLayout());
    south.add(connect);
    south.add(submit);
    south.add(stop);
    
    this.setLayout(new BorderLayout());
    this.add(north, BorderLayout.NORTH);
    this.add(south, BorderLayout.SOUTH);
    
    this.pack();
    this.setVisible(true);
    
  }
  
  public static void main(String[] args)
  {
    new ClientGUI(args[0]); //args[0] represents the title of the GUI
  }
  
  class EventHandler implements ActionListener
  {
	
	private JButton c;
	private JButton sub;
	private JButton stp;
	
	public EventHandler(JButton c, JButton sub, JButton stp)
	{
		this.c = c;
		this.sub = sub;
		this.stp = stp;
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == c) {connect();}
		else if(e.getSource() == sub) {submit();}
		else if(e.getSource() == stp) {stop();}
	}
	
	public void connect()
	{
		System.out.println("Connect Button Pressed");
	}
	
	public void submit()
	{
		System.out.println("Submit Button Pressed");
	}
	
	public void stop()
	{
		System.out.println("Stop Button Pressed");
	}
	  
  }
}
